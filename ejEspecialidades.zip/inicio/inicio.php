<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Miguel Salazar del Bosque</title>
</head>
<body>
	<form action="./qryAutentica.php" method="post">
	<table align="center">
		<tr height="120">
			<td colspan=2><img src="../img/bannerITS.jpg" width='600' height='120'></td>
		</tr>
	</table>
	<table align="center">
		<tr ><td colspan=2></td></tr>
		<tr><td><label>Usuario</label></td>
		<td><input type="text" id="user" name="user"></input></td></tr>
		<tr><td><label>Contraseña</label></td>
		<td><input type="password" id="pass" name="pass"></input></td></tr>
		<tr><td colspan=2 align="center"><button name="enviar">Enviar</button></td></tr>
	</table>
	</form>
</body>
</html>
